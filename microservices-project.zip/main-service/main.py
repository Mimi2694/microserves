from fastapi import FastAPI, HTTPException
import requests
import pika
import json

app = FastAPI()

AUTH_SERVICE = "http://auth-service:8000/validate"


def verify_token(token):

    headers = {"Authorization": f"Bearer {token}"}

    response = requests.get(AUTH_SERVICE, headers=headers)

    if response.status_code != 200:
        raise HTTPException(status_code=401, detail="Invalid token")

    return response.json()


def publish_event(message):

    connection = pika.BlockingConnection(
        pika.ConnectionParameters("rabbitmq")
    )

    channel = connection.channel()

    channel.queue_declare(queue="notifications")

    channel.basic_publish(
        exchange="",
        routing_key="notifications",
        body=json.dumps(message)
    )

    connection.close()


@app.get("/workouts")
def get_workouts(token: str):

    user = verify_token(token)

    publish_event({
        "user": user["sub"],
        "message": "User viewed workouts"
    })

    return {
        "workouts": ["Bench Press", "Squat", "Deadlift"]
    }
