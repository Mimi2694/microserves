from fastapi import FastAPI, Request
import requests

app = FastAPI()

SERVICES = {
    "auth": "http://auth-service:8000",
    "main": "http://main-service:8001"
}


@app.api_route("/{service}/{path:path}", methods=["GET","POST"])
async def gateway(service: str, path: str, request: Request):

    if service not in SERVICES:
        return {"error": "service not found"}

    url = f"{SERVICES[service]}/{path}"

    headers = dict(request.headers)

    if request.method == "GET":
        response = requests.get(url, headers=headers)
    else:
        body = await request.body()
        response = requests.post(url, headers=headers, data=body)

    return response.json()
