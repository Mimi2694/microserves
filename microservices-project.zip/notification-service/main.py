from fastapi import FastAPI
import pika
import json
import threading

app = FastAPI()


def callback(ch, method, properties, body):

    data = json.loads(body)

    print(f"Notification: {data['user']} -> {data['message']}")


def consume():

    connection = pika.BlockingConnection(
        pika.ConnectionParameters("rabbitmq")
    )

    channel = connection.channel()

    channel.queue_declare(queue="notifications")

    channel.basic_consume(
        queue="notifications",
        on_message_callback=callback,
        auto_ack=True
    )

    print("Notification service listening...")

    channel.start_consuming()


threading.Thread(target=consume).start()
